﻿using ProjectManagerService.DataContract;
using ProjectManagerService.EntityFrameworkLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace ProjectManagerService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "ProjectManagerService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select ProjectManagerService.svc or ProjectManagerService.svc.cs at the Solution Explorer and start debugging.
    public class ProjectManagerService : IProjectManagerService
    {
        public string InsertUserDetails(USER_DETAILS model)
        {
            UserDAC srv = new UserDAC();
            return srv.InsertUser(model);
        }
        public int UpdateUserDetails(USER_DETAILS model)
        {
            UserDAC srv = new UserDAC();
            return srv.UpdateUser(model);
        }
        public int SearchUserDetails(USER_DETAILS model)
        {
            UserDAC srv = new UserDAC();
            return srv.SearchUser(model);
        }
        public int DeleteUserDetails(int Id)
        {
            UserDAC srv = new UserDAC();
            return srv.DeleteUser(Id);
        }
        public USER_DETAILS[] getUserList()
        {
            UserDAC srv = new UserDAC();
            return srv.GetUserList();
        }
        public USER_PROFILE[] getProjectUserList()
        {
            ProjectDAC srv = new ProjectDAC();
            return srv.GetProjectUserList();
        }
        public USER_PROFILE[] getManagerList()
        {
            ProjectDAC srv = new ProjectDAC();
            return srv.GetManagerList();
        }
        public int addUpdateProject(USER_PROFILE model)
        {
            ProjectDAC srv = new ProjectDAC();
            return srv.AddUpdateProject(model);
        }
        public int deleteProject(int project_ID, int user_ID)
        {
            ProjectDAC srv = new ProjectDAC();
            return srv.DeleteProject(project_ID, user_ID);
        }
        public TASK_DETAILS_EXTENDED[] getProjectList()
        {
             TaskDAC srv = new TaskDAC();
            return srv.GetProjectList();
        }
        public string addParentTask(string taskname)
        {
            TaskDAC srv = new TaskDAC();
            return srv.AddParentTask(taskname);
        }
        public TASK_DETAILS_EXTENDED[] getParentTaskList()
        {
            TaskDAC srv = new TaskDAC();
            return srv.GetParentTaskList();
        }
        public TASK_DETAILS_EXTENDED[] getTaskUserList()
        {
            TaskDAC srv = new TaskDAC();
            return srv.GetUserList();
        }
        public string addTaskDetails(TASK_DETAILS_EXTENDED model)
        {
            TaskDAC srv = new TaskDAC();
            return srv.AddTaskDetails(model);
        }
        public TASK_DETAILS_EXTENDED[] getTaskDetails(int projID)
        {
            TaskDAC srv = new TaskDAC();
            return srv.GetTaskDetails(projID);
        }
        public int endTask(int Task_ID)
        {
            TaskDAC srv = new TaskDAC();
            return srv.EndTask(Task_ID);
        }
        public bool updateTask(TASK_DETAILS_EXTENDED model)
        {
            TaskDAC srv = new TaskDAC();
            return srv.UpdateTask(model);
        }
    }
}

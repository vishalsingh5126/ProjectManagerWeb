﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ProjectManagerService.DataContract
{
    public class PARENT_TASK_DETAILS
    {
        [Key]
        public int Parent_ID { get; set; }
        public string Parent_Task { get; set; }
    }
}
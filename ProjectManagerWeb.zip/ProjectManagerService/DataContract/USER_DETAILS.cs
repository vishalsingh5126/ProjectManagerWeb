﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace ProjectManagerService.DataContract
{
    [DataContract]
    public class USER_DETAILS
    {
        [DataMember]
        [Key]
        public int User_ID { get; set; }
        [DataMember]
        public string FirstName { get; set; }
        [DataMember]
        public string LastName { get; set; }        
        [DataMember]
        public int Project_ID { get; set; }
        [DataMember]
        public int Employee_ID { get; set; }
        [DataMember]
        public int Task_ID { get; set; }
    }
}
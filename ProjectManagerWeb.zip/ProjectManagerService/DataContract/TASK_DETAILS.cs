﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace ProjectManagerService.DataContract
{
    [DataContract]
    public class TASK_DETAILS
    {
        [DataMember]
        [Key]
        public int Task_ID { get; set; }
        [DataMember]
        public int Parent_ID{ get; set; }
        [DataMember]
        public int Project_ID { get; set; }
        [DataMember]
        public string Task { get; set; }
        [DataMember]
        public DateTime Start_Date { get; set; }
        [DataMember]
        public DateTime End_Date { get; set; }
        [DataMember]
        public int Priority { get; set; }
        [DataMember]
        public bool Status { get; set; }
    }
}
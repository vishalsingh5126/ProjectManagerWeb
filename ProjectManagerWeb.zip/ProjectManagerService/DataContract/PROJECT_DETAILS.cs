﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace ProjectManagerService.DataContract
{
    [DataContract]
    public class PROJECT_DETAILS
    {
        [DataMember]
        [Key]
        public int Project_ID { get; set; }
        [DataMember]
        public string Project { get; set; }
        [DataMember]
        public string StartDate { get; set; }
        [DataMember]
        public string EndDate { get; set; }
        [DataMember]
        public int Priority { get; set; }

    }
}
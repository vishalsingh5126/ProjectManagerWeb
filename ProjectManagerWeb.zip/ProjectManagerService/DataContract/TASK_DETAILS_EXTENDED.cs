﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace ProjectManagerService.DataContract
{
    [NotMapped]
    [DataContract]
    public class TASK_DETAILS_EXTENDED : TASK_DETAILS
    {
        [DataMember]
        public int Employee_id { get; set; }
        [DataMember]
        public int Proj_id { get; set; }
        [DataMember]
        public string Project_Name { get; set; }
        [DataMember]
        public string Employee_Name { get; set; }
        [DataMember]
        public string Parent_Task { get; set; }
        [DataMember]
        public int Employee_number { get; set; }
    }
}
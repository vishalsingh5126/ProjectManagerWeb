﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace ProjectManagerService.DataContract
{
    [DataContract]
    [NotMapped]
    public class USER_PROFILE : PROJECT_DETAILS
    {
        [DataMember]
        public int NumberOfTask { get; set; }
        [DataMember]
        public int CompletedTask { get; set; }
        [DataMember]
        public string ManagerName { get; set; }
        [DataMember]
        public int UserID { get; set; }
        [DataMember]
        public int EmployeeID { get; set; }
    }
}
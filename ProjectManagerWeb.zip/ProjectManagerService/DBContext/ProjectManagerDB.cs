﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using ProjectManagerService.DataContract;

namespace ProjectManagerService.DBContext
{
    public class ProjectManagerDBContext : DbContext
    {
        public ProjectManagerDBContext() : base("DefaultConnection")
        { }
        public DbSet<USER_DETAILS> USER_DETAILS { get; set; }
        public DbSet<PROJECT_DETAILS> PROJECT_DETAILS { get; set; }
        public DbSet<TASK_DETAILS> TASK_DETAILS { get; set; }
        public DbSet<PARENT_TASK_DETAILS> PARENT_TASK_DETAILS { get; set; }
    }
}
﻿using ProjectManagerService.DataContract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace ProjectManagerService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IProjectManagerService" in both code and config file together.
    [ServiceContract]
    public interface IProjectManagerService
    {
        [OperationContract]
        string InsertUserDetails(USER_DETAILS model);
        [OperationContract]
        int UpdateUserDetails(USER_DETAILS model);
        [OperationContract]
        int SearchUserDetails(USER_DETAILS model);
        [OperationContract]
        int DeleteUserDetails(int Id);
        [OperationContract]
        USER_DETAILS[] getUserList();
        [OperationContract]
        USER_PROFILE[] getProjectUserList();
        [OperationContract]
        USER_PROFILE[] getManagerList();
        [OperationContract]
        int addUpdateProject(USER_PROFILE model);
        [OperationContract]
        int deleteProject(int project_ID, int user_ID);
        [OperationContract]
        TASK_DETAILS_EXTENDED[] getProjectList();
        [OperationContract]
        string addParentTask(string taskname); 
        [OperationContract]
        TASK_DETAILS_EXTENDED[] getParentTaskList();
        [OperationContract]
        TASK_DETAILS_EXTENDED[] getTaskUserList();
        [OperationContract]
        string addTaskDetails(TASK_DETAILS_EXTENDED model);
        [OperationContract]
        TASK_DETAILS_EXTENDED[] getTaskDetails(int projID);
        [OperationContract]
        int endTask(int TaskID);
        [OperationContract]
        bool updateTask(TASK_DETAILS_EXTENDED model);
    }
}

﻿using ProjectManagerService.DataContract;
using ProjectManagerService.DBContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjectManagerService.EntityFrameworkLayer
{
    public class TaskDAC
    {
        ProjectManagerDBContextProdFinal _db = new ProjectManagerDBContextProdFinal();
        ProjectManagerDBContextProdFinal _db2 = new ProjectManagerDBContextProdFinal();

        public TASK_DETAILS_EXTENDED[] GetProjectList()
        {
            var query = _db.PROJECT_DETAILS;
            PROJECT_DETAILS[] projectDetails = query.ToArray();
            TASK_DETAILS_EXTENDED[] taskDetailsExtended = new TASK_DETAILS_EXTENDED[projectDetails.Length];
            for (int i = 0; i < projectDetails.Length; i++)
            {
                taskDetailsExtended[i] = new TASK_DETAILS_EXTENDED();
                taskDetailsExtended[i].Proj_id = projectDetails[i].Project_ID;
                taskDetailsExtended[i].Project_Name = projectDetails[i].Project;
            }
                return taskDetailsExtended;
        }

        public TASK_DETAILS_EXTENDED[] GetParentTaskList()
        {
            var query = _db.PARENT_TASK_DETAILS;
            PARENT_TASK_DETAILS[] projectDetails = query.ToArray();
            TASK_DETAILS_EXTENDED[] taskDetailsExtended = new TASK_DETAILS_EXTENDED[projectDetails.Length];
            for (int i = 0; i < projectDetails.Length; i++)
            {
                taskDetailsExtended[i] = new TASK_DETAILS_EXTENDED();
                taskDetailsExtended[i].Parent_Task = projectDetails[i].Parent_Task;
                taskDetailsExtended[i].Parent_ID = projectDetails[i].Parent_ID;
            }
            return taskDetailsExtended;
        }

        public string AddParentTask(string ParentTaskName)
        {
            PARENT_TASK_DETAILS model = new PARENT_TASK_DETAILS()
            {
                Parent_Task = ParentTaskName
            };
            var query = _db.PARENT_TASK_DETAILS.Where(r => r.Parent_Task.ToLower() == model.Parent_Task.ToLower());
            if (query.Count() == 0)
            {
                _db.PARENT_TASK_DETAILS.Add(model);
                _db.SaveChanges();
                return "Task Added Successfully.";
            }
            else
            { return "Task Already Exist."; }
        }
        public TASK_DETAILS_EXTENDED[] GetUserList()
        {
            var query3 = _db.USER_DETAILS;
            USER_DETAILS[] UserArray = query3.ToArray();
            TASK_DETAILS_EXTENDED[] UserList = new TASK_DETAILS_EXTENDED[UserArray.Length];
            for (int i = 0; i < UserArray.Length; i++)
            {
                UserList[i] = new TASK_DETAILS_EXTENDED();
                UserList[i].Employee_Name = UserArray[i].FirstName + " " + UserArray[i].LastName;
                UserList[i].Employee_id = UserArray[i].Employee_ID;
                UserList[i].Employee_number = UserArray[i].User_ID;
            }
            return UserList;
        }
        public string AddTaskDetails(TASK_DETAILS_EXTENDED model)
        {
            TASK_DETAILS details = new TASK_DETAILS()
            {
                End_Date = model.End_Date,
                Start_Date = model.Start_Date,
                Priority = model.Priority,
                Project_ID = model.Project_ID,
                Parent_ID = model.Parent_ID,
                Task = model.Task
            };
            var query = _db.TASK_DETAILS.Where(r => r.Task.ToLower() == details.Task.ToLower()&&r.Priority == details.Priority&&r.Project_ID == details.Project_ID&&r.Parent_ID == details.Parent_ID);
            if (query.Count() == 0)
            {
                _db.TASK_DETAILS.Add(details);
                _db.SaveChanges();
                var taskID = 0;
                var query2 = _db2.TASK_DETAILS.Where(r => r.Task.ToLower() == details.Task.ToLower() && r.Priority == details.Priority && r.Project_ID == details.Project_ID && r.Parent_ID == details.Parent_ID);
                foreach (var item in query2)
                {
                    taskID = item.Task_ID;
                }
                var query1 = _db.USER_DETAILS.Where(r => r.User_ID == model.Employee_number);
                foreach (USER_DETAILS userdetail in query1)
                {
                    userdetail.Task_ID = Convert.ToInt32(taskID);
                }
                _db.SaveChanges();
                return "Details added successfully.";
            }
            else
                return "Task already exist.";
        }
        public TASK_DETAILS_EXTENDED[] GetTaskDetails(int ProjID)
        {
            var query = _db.TASK_DETAILS.Where(x => x.Project_ID == ProjID);
            TASK_DETAILS[] TaskArray = query.ToArray();
            TASK_DETAILS_EXTENDED[] TotalTaskArray = new TASK_DETAILS_EXTENDED[TaskArray.Length];
            var query1 = _db.PARENT_TASK_DETAILS;
            PARENT_TASK_DETAILS[] parentArray = query1.ToArray();
            var query2 = _db.PROJECT_DETAILS;
            PROJECT_DETAILS[] ProjArray = query2.ToArray();
            for (int i = 0; i < TaskArray.Length ; i++)
            {
                TotalTaskArray[i] = new TASK_DETAILS_EXTENDED();
                TotalTaskArray[i].Task_ID = TaskArray[i].Task_ID;
                TotalTaskArray[i].Parent_ID = TaskArray[i].Parent_ID;
                TotalTaskArray[i].Project_ID = TaskArray[i].Project_ID;
                TotalTaskArray[i].Start_Date = TaskArray[i].Start_Date;
                TotalTaskArray[i].End_Date = TaskArray[i].End_Date;
                TotalTaskArray[i].Task = TaskArray[i].Task;
                TotalTaskArray[i].Priority = TaskArray[i].Priority;
                TotalTaskArray[i].Status = TaskArray[i].Status;
                for (int j = 0; j < parentArray.Length; j++)
                {
                    if (parentArray[j].Parent_ID == TaskArray[i].Parent_ID)
                        TotalTaskArray[i].Parent_Task = parentArray[j].Parent_Task;
                }
                for (int k = 0; k < ProjArray.Length; k++)
                {
                    if (ProjArray[k].Project_ID == TaskArray[i].Project_ID)
                        TotalTaskArray[i].Project_Name = ProjArray[k].Project;
                }
            }
            return TotalTaskArray;
        }
        public int EndTask(int Task_ID)
        {
            var query = _db.TASK_DETAILS.Where(r => r.Task_ID == Task_ID);
            foreach (var taskdetail in query)
            {
                taskdetail.Status = true;
            }
            _db.SaveChanges();
            return 1;
        }
        public bool UpdateTask(TASK_DETAILS_EXTENDED model)
        {
            try
            {
                var query = _db.TASK_DETAILS.Where(r => r.Task_ID == model.Task_ID);
                foreach (var taskDetails in query)
                {
                    taskDetails.Start_Date = model.Start_Date;
                    taskDetails.End_Date = model.End_Date;
                    taskDetails.Priority = model.Priority;
                    taskDetails.Task = model.Task;
                    taskDetails.Parent_ID = model.Parent_ID;
                }
                _db.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
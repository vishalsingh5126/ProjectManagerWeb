﻿using ProjectManagerService.DataContract;
using ProjectManagerService.DBContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjectManagerService.EntityFrameworkLayer
{
    public class UserDAC
    {
        ProjectManagerDBContext _db = new ProjectManagerDBContext();
        public string InsertUser(USER_DETAILS model)
        {
            var query = _db.USER_DETAILS.Where(r => r.FirstName.ToLower() == model.FirstName.ToLower() && r.LastName.ToLower() == model.LastName.ToLower() && r.Employee_ID == model.Employee_ID);
            if (query.Count() == 0)
            {
                _db.USER_DETAILS.Add(model);
                _db.SaveChanges();
                return "Details Added successfully.";
            }
            else
            {
                return "User already exist.";
            }            
        }
        public USER_DETAILS[] GetUserList()
        {
            var query3 = _db.USER_DETAILS;
            USER_DETAILS[] UserList = query3.ToArray();
            return UserList;
        }
        public int UpdateUser(USER_DETAILS model)
        {
            var query = _db.USER_DETAILS.Where(r => r.User_ID == model.User_ID);
            foreach (USER_DETAILS userdetail in query)
            {
                userdetail.FirstName = model.FirstName;
                userdetail.LastName = model.LastName;
                userdetail.Employee_ID = model.Employee_ID;
            }
            _db.SaveChanges();
            return 0;
        }
        public int SearchUser(USER_DETAILS model)
        {
            return 0;
        }
        public int DeleteUser(int Id)
        {
            _db.USER_DETAILS.RemoveRange(_db.USER_DETAILS.Where(x => x.User_ID == Id));
            _db.SaveChanges();
            return 0;
        }
    }
}
﻿using ProjectManagerService.DataContract;
using ProjectManagerService.DBContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjectManagerService.EntityFrameworkLayer
{   
    public class ProjectDAC
    {
        ProjectManagerDBContext _db = new ProjectManagerDBContext();
        ProjectManagerDBContext _db1 = new ProjectManagerDBContext();
        ProjectManagerDBContext _db2 = new ProjectManagerDBContext();
        ProjectManagerDBContext _db3 = new ProjectManagerDBContext();
        public USER_PROFILE[] GetProjectUserList()
        {
            var query3 = _db.PROJECT_DETAILS;
            PROJECT_DETAILS[] UserList = query3.ToArray();
            USER_PROFILE[] UserProfile = new USER_PROFILE[UserList.Length];
            for (int i = 0; i < UserProfile.Length; i++)
            {
                UserProfile[i] = new USER_PROFILE();
                var projID = UserList[i].Project_ID;
                UserProfile[i].Project_ID = UserList[i].Project_ID;
                UserProfile[i].Project = UserList[i].Project;
                UserProfile[i].Priority = UserList[i].Priority;
                UserProfile[i].StartDate = UserList[i].StartDate;
                UserProfile[i].EndDate = UserList[i].EndDate;
                UserProfile[i].NumberOfTask = _db.TASK_DETAILS.Count(t => t.Project_ID == projID);
                UserProfile[i].CompletedTask = _db.TASK_DETAILS.Count(t => t.Project_ID == projID && t.Status == true);
                var firstname = "";
                var lastname = "";
                var user = 0;
                var query = _db.USER_DETAILS.Where(r => r.Project_ID == projID);
                foreach (var item in query)
                {
                    firstname = item.FirstName;
                    lastname = item.LastName;
                    user = item.User_ID;
                }
                UserProfile[i].UserID = user;
                UserProfile[i].ManagerName = firstname +" "+lastname;
            }
            return UserProfile;
        }
        public USER_PROFILE[] GetManagerList()
        {
            var query3 = _db.USER_DETAILS;
            USER_DETAILS[] UserList = query3.ToArray();
            USER_PROFILE[] UserProfile = new USER_PROFILE[UserList.Length];
            for (int i = 0; i < UserProfile.Length; i++)
            {
                UserProfile[i] = new USER_PROFILE();
                UserProfile[i].ManagerName = UserList[i].FirstName + " " + UserList[i].LastName;
                UserProfile[i].EmployeeID = UserList[i].Employee_ID;
                UserProfile[i].UserID = UserList[i].User_ID;
            }
            return UserProfile;
        }
        public int AddUpdateProject(USER_PROFILE model)
        {
            PROJECT_DETAILS details = new PROJECT_DETAILS()
            {
                Priority = model.Priority,
                EndDate = model.EndDate,
                StartDate = model.StartDate,
                Project = model.Project,
                Project_ID = model.Project_ID
            };
                if (model.Project_ID == 0)
                {
                    _db.PROJECT_DETAILS.Add(details);
                    _db.SaveChanges();
                var projectID = 0;
                var query = _db1.PROJECT_DETAILS.Where(prj => prj.Project == model.Project && prj.Priority == model.Priority);
                foreach (var item in query)
                {
                    projectID = item.Project_ID;
                }                
                var query1 = _db2.USER_DETAILS.Where(r => r.User_ID == model.UserID);
                foreach (USER_DETAILS userdetail in query1)
                {
                    userdetail.Project_ID = Convert.ToInt32(projectID);
                }
                _db2.SaveChanges();
                return 1;
                }
            else
            {
                var query = _db.PROJECT_DETAILS.Where(r => r.Project_ID == model.Project_ID);
                foreach (var item in query)
                {
                    item.Project = model.Project;
                    item.Priority = model.Priority;
                    item.EndDate = model.EndDate;
                    item.StartDate = model.StartDate;
                }
                _db.SaveChanges();
                var projectID = model.Project_ID;
                var query1 = _db2.USER_DETAILS.Where(r => r.Project_ID == projectID);
                foreach (USER_DETAILS userdetail in query1)
                {
                    userdetail.Project_ID = 0;
                }
                _db2.SaveChanges();
                var query2 = _db3.USER_DETAILS.Where(r => r.User_ID == model.UserID);
                foreach (USER_DETAILS userdetail in query2)
                {
                    userdetail.Project_ID = Convert.ToInt32(projectID);
                }
                _db3.SaveChanges();
                return 1;
            }
        }
        public int DeleteProject(int project_id, int user_ID)
        {
            _db.PROJECT_DETAILS.RemoveRange(_db.PROJECT_DETAILS.Where(x => x.Project_ID == project_id));
            _db.SaveChanges();
            var query1 = _db2.USER_DETAILS.Where(r => r.User_ID == user_ID);
            foreach (USER_DETAILS userdetail in query1)
            {
                userdetail.Project_ID = 0;
            }
            _db2.SaveChanges();
            return 0;
        }
     }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProjectManagerWeb.ProjectManagerService;

namespace ProjectManagerWeb.Controllers
{
    public class ProjectController : Controller
    {
        ProjectManagerServiceClient client = new ProjectManagerServiceClient();
        public ActionResult Index()
        {
            ViewBag.Search = "";
            ViewBag.SDateSortParam = "SD_desc";
            ViewBag.EDateSortParam = "ED_desc";
            ViewBag.PrioritySortParam = "Prio_desc";
            ViewBag.CompletedSortParam = "Comp_desc";
            var list = GetProjectUserList();
            HttpContext.Session["Project"] = list;
            return View("AddProject",list);
        }
        public ActionResult AddUpdateProject(string ProjectName, int ProjectID, int Priority, string StartDate, string EndDate, int EmployeeID)
        {
            ViewBag.Search = "";
            USER_PROFILE DataContract = new USER_PROFILE()
            {
                Priority = Priority,
                Project = ProjectName,
                Project_ID = ProjectID,
                StartDate =StartDate,
                EndDate = EndDate,
                UserID = EmployeeID
            };
            int success = client.addUpdateProject(DataContract);
            var list = GetProjectUserList();
            HttpContext.Session["Project"] = list;
            return PartialView("AddProject",list);
        }
        public ActionResult GetManagerList()
        {
            ViewBag.Search = "";
            USER_PROFILE[] UserDetailArray = client.getManagerList();
            List<USER_PROFILE> UserDetailList = UserDetailArray.ToList();
            //IEnumerable<USER_PROFILE> list = UserDetailList;
            return PartialView("AddProject", UserDetailList);
        }
        public ActionResult DeleteProject(int project_ID, int user_ID)
        {
            ViewBag.Search = "";
            int success = client.deleteProject(project_ID,user_ID);
            var list = GetProjectUserList();
            HttpContext.Session["Project"] = list;
            return PartialView("AddProject", list);
        }

        public List<USER_PROFILE> GetProjectUserList()
        {
            ViewBag.Search = "";
            USER_PROFILE[] UserDetailArray = client.getProjectUserList();
            var UserDetailList = UserDetailArray.ToList();
            return UserDetailList;
        }
        public ActionResult SearchProject(string search)
        {
            ViewBag.Search = search;
            IEnumerable<USER_PROFILE> projectList = (List<USER_PROFILE>)Session["Project"];
            projectList = projectList.Where(r => r.Project.ToLower().Contains(search.ToLower()));
            return PartialView("AddProject", projectList);
        }
        public ActionResult ProjectSort(string sortOrder)
        {
            IEnumerable<USER_PROFILE> projectList = (List<USER_PROFILE>)Session["Project"];
            ViewBag.SDateSortParam = sortOrder == "SD_asc" ? "SD_desc" : "SD_asc";
            ViewBag.EDateSortParam = sortOrder == "ED_asc" ? "ED_desc" : "ED_asc";
            ViewBag.PrioritySortParam = sortOrder == "Prio_asc" ? "Prio_desc" : "Prio_asc";
            ViewBag.CompletedSortParam = sortOrder == "Comp_asc" ? "Comp_desc" : "Comp_asc";
            switch (sortOrder)
            {
                case "SD_desc":
                    projectList = projectList.OrderByDescending(s => s.StartDate);
                    break;
                case "ED_desc":
                    projectList = projectList.OrderByDescending(s => s.EndDate);
                    break;
                case "Prio_desc":
                    projectList = projectList.OrderByDescending(s => s.Priority);
                    break;
                case "Comp_desc":
                    projectList = projectList.OrderByDescending(s => s.CompletedTask);
                    break;
                case "SD_asc":
                    projectList = projectList.OrderBy(s => s.StartDate);
                    break;
                case "ED_asc":
                    projectList = projectList.OrderBy(s => s.EndDate);
                    break;
                case "Prio_asc":
                    projectList = projectList.OrderBy(s => s.Priority);
                    break;
                case "Comp_asc":
                    projectList = projectList.OrderBy(s => s.CompletedTask);
                    break;
                default:
                    projectList = projectList.OrderBy(s => s.StartDate);
                    break;
            }
            return View("AddProject", projectList);
        }
    }
}
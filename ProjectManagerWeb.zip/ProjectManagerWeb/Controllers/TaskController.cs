﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProjectManagerWeb.ProjectManagerService;

namespace ProjectManagerWeb.Controllers
{
    public class TaskController : Controller
    {
        ProjectManagerServiceClient client = new ProjectManagerServiceClient();
        public ActionResult AddTask()
        {
            ViewBag.Message = "";
            List<TASK_DETAILS_EXTENDED> ProjectList = new List<TASK_DETAILS_EXTENDED>();
            return View("AddTask", ProjectList);
        }
        public ActionResult ViewTask()
        {
            ViewBag.SDateSortParam = "SD_desc";
            ViewBag.EDateSortParam = "ED_desc";
            ViewBag.PrioritySortParam = "Prio_desc";
            ViewBag.CompletedSortParam = "Comp_desc";
            List<TASK_DETAILS_EXTENDED> ProjectList = new List<TASK_DETAILS_EXTENDED>();
            return View("ViewTask", ProjectList);
        }
        public ActionResult GetProjectList()
        {
            ViewBag.Message = "";
            TASK_DETAILS_EXTENDED[] ProjectArray = client.getProjectList();
            List<TASK_DETAILS_EXTENDED> ProjectList = ProjectArray.ToList(); 
            return PartialView("AddTask", ProjectList);
        }
        public ActionResult AddUpdateParentTask(string taskName)
        {
            string result = client.addParentTask(taskName);
            ViewBag.Message = result;
            List<TASK_DETAILS_EXTENDED> ProjectList = new List<TASK_DETAILS_EXTENDED>();
            return PartialView("AddTask", ProjectList);
        }
        public ActionResult GetParentTaskList()
        {
            ViewBag.Message = "";
            TASK_DETAILS_EXTENDED[] ProjectArray = client.getParentTaskList();
            List<TASK_DETAILS_EXTENDED> ProjectList = ProjectArray.ToList();
            return PartialView("AddTask", ProjectList);
        }
        public ActionResult GetUserList ()
        {
            TASK_DETAILS_EXTENDED[] userArray = client.getTaskUserList();
            List<TASK_DETAILS_EXTENDED> ProjectList = userArray.ToList();
            return PartialView("AddTask", ProjectList);
        }
        public ActionResult AddTaskDetails (int projectid, int Priority, int parentTaskID, int emploID, DateTime StartDate, DateTime EndDate, string Task)
        {
            TASK_DETAILS_EXTENDED datacontract = new TASK_DETAILS_EXTENDED()
            {
                Employee_number = emploID,
                End_Date = EndDate,
                Start_Date = StartDate,
                Priority = Priority,
                Project_ID = projectid,
                Parent_ID = parentTaskID,
                Task = Task
            };
            string result = client.addTaskDetails(datacontract);
            ViewBag.Message = result;
            List<TASK_DETAILS_EXTENDED> ProjectList = new List<TASK_DETAILS_EXTENDED>();
            return PartialView("AddTask", ProjectList);
        }
        public ActionResult GetTaskDetails(int Project_ID)
        {
            ViewBag.SDateSortParam = "SD_desc";
            ViewBag.EDateSortParam = "ED_desc";
            ViewBag.PrioritySortParam = "Prio_desc";
            ViewBag.CompletedSortParam = "Comp_desc";
            TASK_DETAILS_EXTENDED[] TasKDetailsArray = client.getTaskDetails(Project_ID);
            var TaskDetailsList = TasKDetailsArray.ToList();
            HttpContext.Session["TaskList"] = TaskDetailsList;
            return View("ViewTask", TaskDetailsList);
        }
        public ActionResult EndTask(int Task_ID, int ProjectID)
        {
            int result = client.endTask(Task_ID);
            TASK_DETAILS_EXTENDED[] TasKDetailsArray = client.getTaskDetails(ProjectID);
            var TaskDetailsList = TasKDetailsArray.ToList();
            return View("ViewTask", TaskDetailsList);
        }
        public ActionResult EditTask(DateTime startdate, DateTime enddate, string task, int taskid, int projectid, int parentid, int priority, string parenttask, string projectname)
        {
            TASK_DETAILS_EXTENDED model = new TASK_DETAILS_EXTENDED()
            {
                Start_Date = startdate,
                End_Date = enddate,
                Task = task,
                Task_ID = taskid,
                Project_ID = projectid,
                Parent_ID = parentid,
                Priority = priority,
                Parent_Task = parenttask,
                Project_Name = projectname
            };
            ViewBag.TaskID = model.Task_ID;
            ViewBag.ParentID = model.Parent_ID;
            ViewBag.ProjectID = model.Project_ID;
            List<TASK_DETAILS_EXTENDED> ProjectList = new List<TASK_DETAILS_EXTENDED>();
            ProjectList.Add(model);
            return PartialView("EditTask", ProjectList);
        }
        public ActionResult GetUpdatedParentTaskList()
        {
            ViewBag.Message = "";
            TASK_DETAILS_EXTENDED[] ProjectArray = client.getParentTaskList();
            List<TASK_DETAILS_EXTENDED> ProjectList = ProjectArray.ToList();
            return PartialView("EditTask", ProjectList);
        }
        public ActionResult UpdateTask(int taskid, int parentid, int projectid, DateTime StartDate, DateTime EndDate, string Task, int Priority)
        {
            TASK_DETAILS_EXTENDED model = new TASK_DETAILS_EXTENDED()
            {
                Start_Date = StartDate,
                End_Date = EndDate,
                Task = Task,
                Task_ID = taskid,
                Project_ID = projectid,
                Parent_ID = parentid,
                Priority = Priority
            };
            bool result = client.updateTask(model);
            List<TASK_DETAILS_EXTENDED> ProjectList = new List<TASK_DETAILS_EXTENDED>();
            return View("ViewTask", ProjectList);
        }
        public ActionResult TaskSort(string sortOrder)
        {
            IEnumerable<TASK_DETAILS_EXTENDED> taskList = (List<TASK_DETAILS_EXTENDED>)Session["TaskList"];
            ViewBag.SDateSortParam = sortOrder == "SD_asc" ? "SD_desc" : "SD_asc";
            ViewBag.EDateSortParam = sortOrder == "ED_asc" ? "ED_desc" : "ED_asc";
            ViewBag.PrioritySortParam = sortOrder == "Prio_asc" ? "Prio_desc" : "Prio_asc";
            ViewBag.CompletedSortParam = sortOrder == "Comp_asc" ? "Comp_desc" : "Comp_asc";
            switch (sortOrder)
            {
                case "SD_desc":
                    taskList = taskList.OrderByDescending(s => s.Start_Date);
                    break;
                case "ED_desc":
                    taskList = taskList.OrderByDescending(s => s.End_Date);
                    break;
                case "Prio_desc":
                    taskList = taskList.OrderByDescending(s => s.Priority);
                    break;
                case "Comp_desc":
                    taskList = taskList.OrderByDescending(s => s.Status);
                    break;
                case "SD_asc":
                    taskList = taskList.OrderBy(s => s.Start_Date);
                    break;
                case "ED_asc":
                    taskList = taskList.OrderBy(s => s.End_Date);
                    break;
                case "Prio_asc":
                    taskList = taskList.OrderBy(s => s.Priority);
                    break;
                case "Comp_asc":
                    taskList = taskList.OrderBy(s => s.Status);
                    break;
                default:
                    taskList = taskList.OrderBy(s => s.Start_Date);
                    break;
            }
            return View("ViewTask", taskList);
        }
    }
}
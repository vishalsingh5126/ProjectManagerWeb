﻿using ProjectManagerWeb.Models;
using ProjectManagerWeb.ProjectManagerService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ProjectManagerWeb.Controllers
{
    public class UserController : Controller
    {
        ProjectManagerServiceClient client = new ProjectManagerServiceClient();
        // GET: User
        public ActionResult InsertUpdateUser()
        {
            ViewBag.Message = "";
            ViewBag.Search = "";
            ViewBag.FNameSortParm =  "FN_desc";
            ViewBag.LNameSortParm = "LN_desc";
            ViewBag.IDSortParm = "ID_desc";
            List <USER_DETAILS> list = new List<USER_DETAILS>();
            list = GetUserList();
            HttpContext.Session["User"] = list;
            return View(list);
        }
        public ActionResult AddUpdateUser(string firstname,string  lastname,int employeeId,int Id)
        {
            ViewBag.Message = "";
            ViewBag.Search = "";
            USER_DETAILS datacontract = new USER_DETAILS()
            {
                FirstName = firstname,
                LastName = lastname,
                Employee_ID = employeeId,
                User_ID = Id
            };
            string InsertSuccess = "";
            if (Id == 0)
            {
                 InsertSuccess = client.InsertUserDetails(datacontract);
                if(InsertSuccess == "User already exist.")
                ViewBag.Message = InsertSuccess;
            }
            else
            {
                int UpdateSuccess = client.UpdateUserDetails(datacontract);
            }
            List<USER_DETAILS> list = new List<USER_DETAILS>();
            list = GetUserList();
            HttpContext.Session["User"] = list;
            return PartialView("InsertUpdateUser", list);
        }
        public ActionResult DeleteUser(int id)
        {
            ViewBag.Message = "";
            ViewBag.Search = "";
            int success = client.DeleteUserDetails(id);
            List<USER_DETAILS> list = new List<USER_DETAILS>();
            list = GetUserList();
            HttpContext.Session["User"] = list;
            return PartialView("InsertUpdateUser", list);
        }
        public ActionResult SearchUser(string search)
        {
            ViewBag.Message = "";
            ViewBag.Search = search;
            IEnumerable < USER_DETAILS> UserList = (List< USER_DETAILS >) Session["User"];
            UserList = UserList.Where(r => r.FirstName.ToLower().Contains(search.ToLower()) || r.LastName.ToLower().Contains(search.ToLower()) || r.Employee_ID.ToString().ToLower().Contains(search.ToLower()));
            return PartialView("InsertUpdateUser", UserList);
        }
        public List<USER_DETAILS> GetUserList()
        {
            USER_DETAILS[] UserDetailArray = client.getUserList();
            var UserDetailList = UserDetailArray.ToList();
            return UserDetailList;
        }
        public ActionResult SortList(string sortOrder)
        {
            List<USER_DETAILS> list = new List<USER_DETAILS>();
            list = GetUserList();
            IEnumerable<USER_DETAILS> UserList = (List<USER_DETAILS>)Session["User"];
            ViewBag.IDSortParm = sortOrder == "ID_asc" ? "ID_desc" : "ID_asc";
            ViewBag.LNameSortParm = sortOrder == "LN_asc" ? "LN_desc" : "LN_asc";
            ViewBag.FNameSortParm = sortOrder == "FN_asc" ? "FN_desc" : "FN_asc";
            switch (sortOrder)
            {
                case "FN_desc":
                    UserList = UserList.OrderByDescending(s => s.FirstName);
                    break;
                case "LN_desc":
                    UserList = UserList.OrderByDescending(s => s.LastName);
                    break;
                case "ID_desc":
                    UserList = UserList.OrderByDescending(s => s.Employee_ID);
                    break;
                case "FN_asc":
                    UserList = UserList.OrderBy(s => s.FirstName);
                    break;
                case "LN_asc":
                    UserList = UserList.OrderBy(s => s.LastName);
                    break;
                case "ID_asc":
                    UserList = UserList.OrderBy(s => s.Employee_ID);
                    break;
                default:
                    UserList = UserList.OrderBy(s => s.FirstName);
                    break;
            }
            return View("InsertUpdateUser", UserList);
        }
    }
}
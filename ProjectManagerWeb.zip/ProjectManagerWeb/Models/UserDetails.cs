﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjectManagerWeb.Models
{
    public class UserDetails
    {
        public int ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int UserID { get; set; }
        public int ProjectID { get; set; }
        public int EmployeeID { get; set; }
        public int TaskID { get; set; }
    }
}
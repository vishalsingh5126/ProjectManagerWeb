﻿var TodayDate = "";
var TomorrowDate = "";
var count = 0;
var Mid = 0;
var PID = 0;
$(document).ready(function () {
    
    $('input[type="checkbox"]').click(function () {
        if (count != 1) {
            count = 1;
            TodayDate = $('#StartDate').val();
            TomorrowDate = $('#EndDate').val();
        }
        if ($(this).prop("checked") == true) {
            $("#StartDate").removeAttr("disabled");
            $("#EndDate").removeAttr("disabled");
        }
        else {
            $("#StartDate").attr("disabled", "disabled");
            $("#EndDate").attr("disabled", "disabled");
        }
    });
    $("#btnReset").click(function () {
        if (count == 1) {
            $('#StartDate').val(TodayDate);
            $('#EndDate').val(TomorrowDate);
        }
        Mid = 0;
        PID = 0;
        $("#StartDate").attr("disabled", "disabled");
        $("#EndDate").attr("disabled", "disabled");
        $('#txtManager').val('');
        $('#ProjectTitle').val('');
        $('#dateCheckbox').prop('checked', false);
        $('#rgpriority').prop('value', 0);
        $('#lblProjectError').css("display", "none");
        $('#lblManagerError').css("display", "none");
        $('#btnAddUser').val("Add");
        var output = document.getElementById("lblPriority");
        output.innerHTML = 0;

        slider.oninput = function () {
            output.innerHTML = this.value;
        }
    });
    $("#btnAddUser").click(function () {
        var ProjectName = $('#ProjectTitle').val();
        var StartDate = "";//$('#StartDate').val();
        var EndDate = "";//$('#EndDate').val();

        if ($('#dateCheckbox').is(':checked')) {
            StartDate = $('#StartDate').val();
            EndDate = $('#EndDate').val();
        }
        var ManagerName = $('#txtManager').val();
        var Priority = document.getElementById("rgpriority").value;
        var ProjectID = PID;
        var EmployeeID = Mid;
        if (ProjectName == ""|| ManagerName == "")
        {
            $('#lblProjectError').css("display", "");
            $('#lblManagerError').css("display", "");
        }
        else
        {
            $.ajax({
                url: "/Project/AddUpdateProject/",
                type: "POST",
                data: {
                    ProjectName: ProjectName,
                    ProjectID: ProjectID,
                    Priority: Priority,
                    StartDate: StartDate,
                    EndDate: EndDate,
                    EmployeeID: EmployeeID
                },
                success: function (data) {
                    $('#content').html(data);
                },
                error: function (result) {
                    console.log("Error saving data");
                }
            });
        }
    });
    $("#btnSelectManager").click(function () {
        
        $.ajax({
            url: "/Project/GetManagerList/",
            type: "POST",
            success: function (data) {
                debugger
                $('#searchModal').modal('show');
                $('#searchModal').html($(data).find('#searchModal').html())
                $("#modaltable").dataTable();
            },
            error: function (result) {
                console.log("Error occured");
            }
        });
    });
    $("#btnSearch").click(function () {
        var search = $('#txtSearch').val();
        $.ajax({
            url: "/Project/SearchProject/",
            type: "POST",
            data: {
                search: search
            },
            success: function (data) {
                $('#content').html(data);
            },
            error: function (result) {
                console.log("Error Searching Project");
            }
        });
    });
    $("#StartDate").change(function () {
        var startDate = $('#StartDate').val();
        $('#EndDate').val('');
        $("#EndDate").attr("min", startDate);
    });
    $("#EndDate").change(function () {
        var endDate = $('#EndDate').val();
    });
});
function SelectManager(managerName, managerID) {
    Mid = managerID;
    $('#txtManager').val(managerName);
    $('#searchModal').modal('hide');
};
function UpdateProject(EndDate, StartDate, Project, Project_ID, Priority, UserID, ManagerName) {
    Mid = UserID;
    PID = Project_ID;
    count = 1;
    TodayDate = $('#StartDate').val();
    TomorrowDate = $('#EndDate').val();
    $('#btnAddUser').val("Update");
    if (StartDate != "" || EndDate != "") {
        $('#EndDate').val(EndDate);
        $('#StartDate').val(StartDate);
        $('#dateCheckbox').prop('checked', true);
        $("#StartDate").removeAttr("disabled");
        $("#EndDate").removeAttr("disabled");
    }
    else
    {
        $('#dateCheckbox').prop('checked', false);
        $("#StartDate").attr("disabled", "disabled");
        $("#EndDate").attr("disabled", "disabled");
    }
    $('#txtManager').val(ManagerName);
    $('#ProjectTitle').val(Project);
    $('#rgpriority').prop('value', Priority);
};
function deleteProject(project_ID, user_ID) {
    $.ajax({
        url: "/Project/DeleteProject/",
        type: "POST",
        data: {
            project_ID: project_ID,
            user_ID: user_ID
        },
        success: function (data) {
            $('#content').html(data);
        },
        error: function (result) {
            console.log("Error removing project data");
        }
    });
};
function ProjectSort(SDSPram, EDSPRAM, PSPRAM, CSPRAM, text) {
    var sortOrder = "";
    if (text == "Start") {
        sortOrder = SDSPram;
    }
    else if (text == "End") {
        sortOrder = EDSPRAM;
    }
    else if (text == "Priority") {
        sortOrder = PSPRAM
    }
    else {
        sortOrder = CSPRAM
    }
    $.ajax({
        url: "/Project/ProjectSort/",
        type: "POST",
        data: {
            sortOrder: sortOrder
        },
        success: function (data, textStatus, jqXHR) {
            $('#content').html(data);
        },
        error: function (result) {
            console.log("Error Sorting Project");
        }
    });
}


























//    $(function () {
//        var dateFormat = "mm/dd/yy",
//        from = $("#StartDate") .datepicker({
//                defaultDate: +0,
//                changeMonth: true,
//                changeYear: true,
//                showButtonPanel: true,
//                minDate: 0
//            })
//        .on("change", function () {
//            to.datepicker("option", "minDate", getDate(this));
//            var endDate = document.getElementById('EndDate').value;
//            var startDate = document.getElementById('StartDate').value;
//            $('#EndDate').val('');

//            if (endDate == startDate) {
//                $('#EndDate').val('');
//            }
//        }),
//        to = $("#EndDate").datepicker({
//            defaultDate: +1,
//            changeMonth: true,
//            changeYear: true,
//            showButtonPanel: true,
//            minDate: +1
//        })
//         .on("change", function () {
//             from.datepicker("option", "maxDate", getDate(this));
//             var endDate = document.getElementById('EndDate').value;
//             var startDate = document.getElementById('StartDate').value;
//             if (endDate == startDate) {
//                 alert("Expiry Date Cannot be Equal to Start Date.");
//                 $('#EndDate').val('')
//             }
//         });
//        var old_goToToday = $.datepicker._gotoToday
//        $.datepicker._gotoToday = function (id) {
//            old_goToToday.call(this, id)
//            this._selectDate(id)
//        }
//        function getDate(element) {
//            var date;
//            try {
//                date = $.datepicker.parseDate(dateFormat, element.value);
//            } catch (error) {
//                date = null;
//            }
//            return date;
//        }
//    });
////    if ($("#SelectDate").prop('checked') == true) {
////    alert("Checked");
//    //}
﻿var ParentTaskID = 0;
var parent_ID = 0;
var Project_ID = 0;
$(document).ready(function () {
    $("#btnRemoveParentTask").click(function () {
        $('#txtSearchParentTask').val("");
        ParentTaskID = 0;
    });
    $("#btnSearchParentTask").click(function () {
        $.ajax({
            url: "/Task/GetUpdatedParentTaskList/",
            type: "POST",
            success: function (data) {
                debugger
                $('#ParentTaskModalNew').show();
                $('#ParentTaskModalNew').html($(data).find('#ParentTaskModalNew').html())
                $("#Parenttable").dataTable();
            },
            error: function (result) {
                console.log("Error occured");
            }
        });
    });
    $("#StartDate").change(function () {
        var startDate = $('#StartDate').val();
        $('#EndDate').val('');
        $("#EndDate").attr("min", startDate);
    });
    $("#EndDate").change(function () {
        var endDate = $('#EndDate').val();
    });

});
function SelectParentTask(parentTask, parentID) {
    parent_ID = parentID;
    $('#txtSearchParentTask').val(parentTask);
    $('#ParentTaskModalNew').hide();
};
function EditTask(taskid,parentid,projectid) {
    if(parent_ID == 0)
    { parentid = parent_ID; }
    var StartDate = $('#StartDate').val();
    var EndDate = $('#EndDate').val();
    var Task = $('#txtTask').val();
    var Priority = document.getElementById("PriorityRange").value;
    var ParentTaskName = $('#txtSearchParentTask').val();
    if (ParentTaskName == "")
    {
        parentid = 0;
    }
    if (Task =="" || Priority == "0" ||StartDate == "" || EndDate == "")
    {
        $('#lblPriorityError').css("display", "");
        $('#lbDateError').css("display", "");
        $('#lblTaskError').css("display", "");
    }
    else
    {
        $.ajax({
            url: "/Task/UpdateTask/",
            type: "POST",
            data: {
                taskid: taskid,
                parentid: parentid,
                projectid: projectid,
                StartDate: StartDate,
                EndDate: EndDate,
                Task: Task,
                Priority: Priority
            },
            success: function (data) {
                $('#content').html(data);
            },
            error: function (result) {
                console.log("Error saving data");
            }
        });
    }
       
}
function HideModal() {
    $('#ParentTaskModalNew').hide();
};
﻿var projID = 0;
$(document).ready(function () {
    $("#btnSearchProject").click(function () {

        $.ajax({
            url: "/Task/GetProjectList/",
            type: "POST",
            success: function (data) {
                debugger
                $('#searchModal').show();
                $('#searchModal').html($(data).find('#searchModal').html())
                $("#modaltable").dataTable();
            },
            error: function (result) {
                console.log("Error occured");
            }
        });
    });
});
function SelectProject(ProjectName, ProjectID) {
    projID = ProjectID;
    var Project_ID = ProjectID;
    $('#txtSearchProject').val(ProjectName);
    $('#searchModal').hide();
    $.ajax({
        url: "/Task/GetTaskDetails/",
        type: "POST",
        data: {
            Project_ID: Project_ID           
        },
        success: function (data) {
            $('#content').html(data);
        },
        error: function (result) {
            console.log("Error saving data");
        }
    });
};
function EndTask(Task_ID, ProjectID) {
    $.ajax({
        url: "/Task/EndTask/",
        type: "POST",
        data: {
            Task_ID: Task_ID,
            ProjectID: ProjectID
        },
        success: function (data) {
            $('#content').html(data);
        },
        error: function (result) {
            console.log("Error saving data");
        }
    });
};
function EditTask(startdate, enddate, task, taskid, projectid, parentid, priority, parenttask, projectname) {
    $.ajax({
        url: "/Task/EditTask/",
        type: "POST",
        data: {
            startdate: startdate,
            enddate: enddate,
            task: task,
            taskid: taskid,
            projectid: projectid,
            parentid: parentid,
            priority: priority,
            parenttask: parenttask,
            projectname: projectname
        },
        success: function (data) {
            $('#content').html(data);
        },
        error: function (result) {
            console.log("Error saving data");
        }
    });
};
function HideModal() {
    $('#searchModal').hide();
};
function TaskSort(SDSPram, EDSPRAM, PSPRAM, CSPRAM, text) {
    var sortOrder = "";
    if (text == "Start") {
        sortOrder = SDSPram;
    }
    else if (text == "End") {
        sortOrder = EDSPRAM;
    }
    else if (text == "Priority") {
        sortOrder = PSPRAM
    }
    else {
        sortOrder = CSPRAM
    }
    $.ajax({
        url: "/Task/TaskSort/",
        type: "POST",
        data: {
            sortOrder: sortOrder
        },
        success: function (data, textStatus, jqXHR) {
            $('#content').html(data);
        },
        error: function (result) {
            console.log("Error Sorting Project");
        }
    });
}
﻿var count = 0;
var projID = 0;
var parent_ID = 0;
var empId = 0;
$(document).ready(function () {
    $("#ParentTaskcheckbox").click(function () {
        if ($(this).prop("checked") == true) {
            $('#PriorityRange').prop('value', 0);
            document.getElementById("PriorityRange").disabled = true;
            $('#btnSearchParentTask').prop("disabled", true);
            $('#btnSearchUser').prop("disabled", true);
            $("#StartDate").attr("disabled", "disabled");
            $("#EndDate").attr("disabled", "disabled");
            $('#txtSearchProject').val("");
            $('#SearchUser').val("");
            $('#txtSearchParentTask').val("");
            $("#txtTask").removeAttr("disabled");
            $('#btnSearchProject').prop("disabled", true);
            projID = 0;
            parent_ID = 0;
            empId = 0;
            var output = document.getElementById("lblPriority");
            output.innerHTML = 0;

            slider.oninput = function () {
                output.innerHTML = this.value;
            }
        }
        else
        {
            $("#txtTask").attr("disabled", "disabled");
            $('#PriorityRange').prop('value', 0);
            $("#StartDate").removeAttr("disabled");
            $("#EndDate").removeAttr("disabled");
            $("#btnSearchUser").removeAttr("disabled");
            $("#btnSearchProject").removeAttr("disabled");
            $("#btnSearchParentTask").removeAttr("disabled");
            document.getElementById("PriorityRange").disabled = false;
        }
    });
    $("#btnSearchProject").click(function () {

        $.ajax({
            url: "/Task/GetProjectList/",
            type: "POST",
            success: function (data) {
                $('#searchModal').modal('show');
                $('#searchModal').html($(data).find('#searchModal').html())
                $("#modaltable").dataTable();
            },
            error: function (result) {
                console.log("Error occured");
            }
        });
    });
    $("#btnSearchParentTask").click(function () {

        $.ajax({
            url: "/Task/GetParentTaskList/",
            type: "POST",
            success: function (data) {
                $('#ParentTaskModalNew').modal('show');
                $('#ParentTaskModalNew').html($(data).find('#ParentTaskModalNew').html())
                $("#Parenttable").dataTable();
            },
            error: function (result) {
                console.log("Error occured");
            }
        });
    });
    $("#btnSearchUser").click(function () {

        $.ajax({
            url: "/Task/GetUserList/",
            type: "POST",
            success: function (data) {
                $('#UserModal').modal('show');
                $('#UserModal').html($(data).find('#UserModal').html())
                $("#Usertable").dataTable();
            },
            error: function (result) {
                console.log("Error occured");
            }
        });
    });
    
    $("#btnAdd").click(function () {
        if ($('#ParentTaskcheckbox').prop("checked") == true) {
            
            var taskName = $('#txtTask').val();
            if (taskName == "") {
                
                $('#lblTaskError').css("display", "");
            }
            else {
                $.ajax({
                    url: "/Task/AddUpdateParentTask/",
                    type: "POST",
                    data: {
                        taskName: taskName
                    },
                    success: function (data) {
                        $('#content').html(data);
                    },
                    error: function (result) {
                        console.log("Error saving data");
                    }
                });
            }
        }
        else
        {
            
            var projectid = projID;
            var Priority = document.getElementById("PriorityRange").value;
            var ParentTaskName = $('#txtSearchParentTask').val();
            var parentTaskID = parent_ID;
            var UserName = $('#SearchUser').val();
            var StartDate = $('#StartDate').val();
            var EndDate = $('#EndDate').val();
            var Task = $('#txtTask').val();
            var emploID = empId;
            //alert(Task+" "+ projectName+" "+Priority+" "+ParentTaskName+ " "+ UserName+" "+ StartDate+" "+ EndDate);
            if (Task =="" || Priority == "0" || UserName == "" || StartDate == "" || EndDate == "")
            {
                $('#lblProjectError').css("display", "");
                $('#lblPriorityError').css("display", "");
                $('#lblUserError').css("display", "");
                $('#lbDateError').css("display", ""); 
                $('#lblTaskError').css("display", "");
            }
            else
            {
                $.ajax({
                    url: "/Task/AddTaskDetails/",
                    type: "POST",
                    data: {
                        projectid: projectid,
                        Priority: Priority,
                        parentTaskID: parentTaskID,
                        emploID: emploID,
                        StartDate: StartDate,
                        EndDate: EndDate,
                        Task: Task
                    },
                    success: function (data) {
                        $('#content').html(data);
                    },
                    error: function (result) {
                        console.log("Error saving data");
                    }
                });
            }
        }
    });
    $("#StartDate").change(function () {
        var startDate = $('#StartDate').val();
        $('#EndDate').val('');
        $("#EndDate").attr("min", startDate);
    });
    $("#EndDate").change(function () {
        var endDate = $('#EndDate').val();
    });
});
function SelectProject(ProjectName, ProjectID){
    projID = ProjectID;
    $('#txtSearchProject').val(ProjectName);
    $('#searchModal').modal('hide');
};
function SelectParentTask(parentTask, parentID) {
    parent_ID = parentID;
    $('#txtSearchParentTask').val(parentTask);
    $('#ParentTaskModalNew').modal('hide')
};
function SelectUser(EmployeeID, EmployeeName) {
    empId = EmployeeID;
    $('#SearchUser').val(EmployeeName);
    $('#UserModal').modal('hide');
};
function HideModal() {
    $('#ParentTaskModalNew').modal('hide');
}; 
function Reset(startdate, endDate) {

    projID = 0;
    parent_ID = 0;
    empId = 0;
    $('#txtSearchParentTask').val("");
    $('#StartDate').val(startdate);
    $('#txtTask').val("");
    $('#SearchUser').val("");
    $('#ParentTaskcheckbox').prop('checked', false);
    $('#EndDate').val(endDate);
    var output = document.getElementById("lblPriority");
    output.innerHTML = 0;

    slider.oninput = function () {
        output.innerHTML = this.value;
    }
    $('#PriorityRange').prop('value', 0);
    $("#StartDate").removeAttr("disabled");
    $("#EndDate").removeAttr("disabled");
    $("#btnSearchUser").removeAttr("disabled");
    $("#btnSearchProject").removeAttr("disabled");
    $("#btnSearchParentTask").removeAttr("disabled");
    document.getElementById("PriorityRange").disabled = false;
};
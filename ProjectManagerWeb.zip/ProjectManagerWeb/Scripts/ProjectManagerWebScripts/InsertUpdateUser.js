﻿var Id = 0;
$(document).ready(function () {
    $("#btnSearch").click(function () {
        var search = $('#txtSearch').val();
        $.ajax({
            url: "/User/SearchUser/",
            type: "POST",
            data: {
                search: search
            },
            success: function (data, textStatus, jqXHR) {
                $('#content').html(data);
            },
            error: function (result) {
                console.log("Error Searching User");
            }
        });
    });
    $("#btnReset").click(function () {
        Id = 0;
        $('#FirstName').val('');
        $('#LastName').val('');
        $('#EmployeeID').val('');
        $('#btnAddUser').val("Add");
    });
});
function AddUpdateUser()
{
    var firstname = $('#FirstName').val();
    var lastname = $('#LastName').val();
    var employeeId = $('#EmployeeID').val();
    if (firstname != "" && lastname != "" && employeeId != 0) {
        $.ajax({
            url: "/User/AddUpdateUser/",
            type: "POST",
            data: {
                firstname: firstname,
                lastname: lastname,
                employeeId: employeeId,
                Id: Id
            },
            success: function (data, textStatus, jqXHR) {
                $('#content').html(data);
            },
            error: function (result) {
                console.log("Error saving data");
            }
        });
    }
    else {
        alert("Please enter first name, last name and employee Id.");
    }
}
function EditUser(firstname,lastname,employeeId,id)
{
    $('#FirstName').val('');
    $('#LastName').val('');
    $('#EmployeeID').val('');
    $('#FirstName').val(firstname);
    $('#LastName').val(lastname);
    $('#EmployeeID').val(employeeId);
    Id = id;
    $('#btnAddUser').val("Update");
}
function DeleteUser(id)
{
    $.ajax({
        url: "/User/DeleteUser/",
        type: "POST",
        data: {
            id: id
        },
        success: function (data, textStatus, jqXHR) {
            $('#content').html(data);
        },
        error: function (result) {
            console.log("Error saving quick links");
        }
    });
}

function SortList(FN_sort, LN_Sort, ID_Sort, text) {
    var sortOrder = "";
    if (text == "first") {
        sortOrder = FN_sort;
    }
    else if (text == "last") {
        sortOrder = LN_Sort;
    }
    else {
        sortOrder = ID_Sort
    }
    $.ajax({
        url: "/User/SortList/",
        type: "POST",
        data: {
            sortOrder: sortOrder
        },
        success: function (data, textStatus, jqXHR) {
            $('#content').html(data);
        },
        error: function (result) {
            console.log("Error Searching User");
        }
    });
}